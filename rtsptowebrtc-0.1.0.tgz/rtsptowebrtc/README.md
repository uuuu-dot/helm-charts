# RTSPtoWebRTC Helm Chart

这个 Helm Chart 用于部署 RTSPtoWebRTC 服务，将 RTSP 视频流转换为 WebRTC 并在浏览器中低延迟播放。

## 安装

### 通过 Helm 仓库安装

```bash
# 添加 Helm 仓库
helm repo add rtsp https://uuuu-dot.github.io/helm-charts
helm repo update

# 安装 Chart，指定 RTSP URL
helm install cam1 rtsp/rtsptowebrtc --set rtsp.url="rtsp://用户名:密码@摄像头地址:端口"
```

### 本地安装

```bash
# 克隆仓库
git clone https://github.com/deepch/RTSPtoWebRTC.git
cd RTSPtoWebRTC/helm

# 安装 Chart
helm install cam1 ./rtsptowebrtc --set rtsp.url="rtsp://用户名:密码@摄像头地址:端口"
```

## 配置参数

以下是常用的配置参数：

| 参数 | 描述 | 默认值 |
|------|------|--------|
| `replicaCount` | Pod 副本数 | `1` |
| `image.repository` | 镜像名称 | `rtsp2webrtc` |
| `image.tag` | 镜像标签 | `minimal` |
| `image.pullPolicy` | 镜像拉取策略 | `IfNotPresent` |
| `service.type` | 服务类型 | `NodePort` |
| `service.port` | 服务端口 | `8083` |
| `service.nodePort` | NodePort 端口 (可选) | `30083` |
| `rtsp.url` | RTSP 摄像头地址 | `rtsp://...` |
| `hostNetwork` | 是否使用 host 网络模式 | `false` |
| `ingress.enabled` | 是否启用 Ingress | `false` |

## 使用示例

1. 使用 NodePort 服务类型安装：

```bash
helm install cam1 rtsp/rtsptowebrtc \
  --set rtsp.url="rtsp://guest:HelloShifu@bj-hikcamera-01.saifai.cn:40554" \
  --set service.type=NodePort \
  --set service.nodePort=30083
```

2. 如果在 Docker 环境中遇到网络问题，尝试使用 host 网络模式：

```bash
helm install cam1 rtsp/rtsptowebrtc \
  --set rtsp.url="rtsp://guest:HelloShifu@bj-hikcamera-01.saifai.cn:40554" \
  --set hostNetwork=true
```

3. 使用 LoadBalancer 服务类型安装：

```bash
helm install cam1 rtsp/rtsptowebrtc \
  --set rtsp.url="rtsp://guest:HelloShifu@bj-hikcamera-01.saifai.cn:40554" \
  --set service.type=LoadBalancer
```

4. 启用 Ingress：

```bash
helm install cam1 rtsp/rtsptowebrtc \
  --set rtsp.url="rtsp://guest:HelloShifu@bj-hikcamera-01.saifai.cn:40554" \
  --set ingress.enabled=true \
  --set ingress.hosts[0].host=rtsp.example.com \
  --set ingress.hosts[0].paths[0].path=/
```

## 访问应用

安装后，可以通过以下方式访问应用：

- **NodePort**: 访问任意节点的 IP 加上 NodePort 端口 (默认 30083)
- **LoadBalancer**: 访问负载均衡器分配的 IP 和端口
- **Ingress**: 访问配置的域名
- **Host Network**: 访问运行 Pod 的节点 IP 的 8083 端口

## 更新配置

要更改 RTSP URL 或其他配置，使用 `helm upgrade` 命令：

```bash
helm upgrade cam1 rtsp/rtsptowebrtc --set rtsp.url="rtsp://新的用户名:密码@摄像头地址:端口"
```

## 卸载

```bash
helm uninstall cam1
``` 